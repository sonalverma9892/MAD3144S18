

function validateLogin(e) {
        var un = document.loginform.usr.value;
        var pw = document.loginform.pword.value;
        var pwd = localStorage.getItem('newPass1');
        console.log(pwd);

        if (un == "sonal" && pw == "test") {
          localStorage.setItem('username', 'sonal');
          return true;

        }else if (un == "sonal" && pw == pwd) {
          localStorage.setItem('username', 'sonal');
          return true;

          return true;
        }else if((un == "ankur") && (pw == "test")) {
          localStorage.setItem('username', 'ankur');
          return true;
          // e.preventDefault();
          // window.location.assign("menu2.html");

        }else if (un == "ankur" && pw == pwd) {
          localStorage.setItem('username', 'ankur');
          return true;
          // e.preventDefault();
          // window.location.assign("menu2.html");

        }else if((un == "admin") && (pw == "admin")){
          e.preventDefault();
          newDoc();

        }
        else {
            alert ("Login was unsuccessful, please check your username and password");
            e.preventDefault();
            return false;
        }
  }

  function newDoc() {
    window.location.assign("admin.html");
}
