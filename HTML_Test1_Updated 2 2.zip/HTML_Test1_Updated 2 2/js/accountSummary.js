$(document).ready(function() {
  var name = localStorage.getItem('username');
  var source = localStorage.getItem('source');
  console.log(name);
  console.log(source);
  var bodyTable = $("#summary").find("tbody");
  var bodyTableUser2 = $("#summaryUser2").find("tbody");

  if(name == "sonal" && source == "CHECK01"){

    $("#summaryUser2").hide();
    var dateData = "03/09/2016";
    var out = localStorage.getItem('amount');;
    var In = "";
    var sub = 1000-parseInt(out);
    if (sub < 0){
      sub = 0;
    }
    var line = newLine(dateData, out, In, sub);
    line.find(".button-remove").click(removeLine);
    bodyTable.prepend(line);
    localStorage.setItem('totalBalUser1', sub);

  }else if(name == "ankur" && source == "CHECK01"){
    $("#summary").hide();
    var dateData = "03/09/2016";
    var out = "";
    var In = localStorage.getItem('amount');
    var sub = parseInt(In)+1000;
    var line = newLine(dateData, out, In, sub);
    line.find(".button-remove").click(removeLine);
    bodyTableUser2.prepend(line);
    localStorage.setItem('totalBalUser2', sub);

  }else if (name == "ankur" && source == "CHECK02") {
    // var bodyTable = $("#summaryUser2").find("tbody");
    $("#summary").hide();
    var dateData = "03/09/2016";
    var out = localStorage.getItem('amount');;
    var In = "";
    var sub = 1000-parseInt(out);
    if (sub < 0){
      sub = 0;
    }
    var line = newLine(dateData, out, In, sub);
    line.find(".button-remove").click(removeLine);
    bodyTableUser2.prepend(line);
    localStorage.setItem('totalBalUser2', sub);

  }else if (name == "sonal" && source == "CHECK02") {
    // var bodyTable = $("#summary").find("tbody");
    $("#summaryUser2").hide();
    var dateData = "03/09/2016";
    var out = "";
    var In = localStorage.getItem('amount');
    var sub = parseInt(In)+1000;
    var line = newLine(dateData, out, In, sub);
    line.find(".button-remove").click(removeLine);
    bodyTable.prepend(line);
    localStorage.setItem('totalBalUser1', sub);
  }


  function removeLine (event) {
    event.preventDefault();
    $(this).parent().parent().remove();
  }

  function newLine(dateData, amount, In, sub){

    console.log(dateData);
    console.log(amount);
    console.log(In);
    console.log(sub);

    var line = $("<tr>");

    var columnDate   = $("<td>").text(dateData);
    var columnOut  = $("<td>").text(amount);
    var columnIn   = $("<td>").text(In);
    var columnBal  = $("<td>").text(sub);
    var columnRemove = $("<td>");

    var link = $("<a>").attr("href","#").addClass("button-remove");
    var icon = $("<i>").addClass("small").addClass("material-icons").text("delete");

    link.append(icon);

    columnRemove.append(link);

    line.append(columnDate);
    line.append(columnOut);
    line.append(columnIn);
    line.append(columnBal);
    line.append(columnRemove);

    return line;
  }

});
