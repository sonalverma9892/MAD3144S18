# resume
Simple printable Css/html resume

This should print fine on a4 size pdf.  You will need to select print options > print background images, and > margin 0,0,0,0 and make sure title, page number and url aren't printed. Enjoy!

an example is included - Resume.pdf
